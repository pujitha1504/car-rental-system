<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sample Form</title> 
	<link rel="stylesheet" href="style.css"> 
	<script type="text/javascript" src="data.js"></script>
	<link rel="shortcut icon" type="image/png" href="logo.jpg">
</head>

<body class="imgbt"><br>
	<img src="logo.jpg" width="100" height="100">
	<div class="card"><br>
		<legend><h2><b><center>Create a new account</center></b></h2></legend>  
		<form method="POST" style="text-align: center;">
		<input class="in" type="text" placeholder="Enter the first name " required><br><br>
		<input class="in" type="text" placeholder="Enter the last name " required><br><br> 
		<input class="in" type="email" placeholder="Enter the email " required><br><br>  
		<input class="in" type="password" placeholder="Enter the password " required><br>
		
		<label class="l"><h5>Date of Birth </h5></label>
	    <div class="field-inline-block">
	      <label>DD</label>
	      <input type="text" pattern="[0-9]*" maxlength="2" size="2" class="date-field" />
	    </div>
	    /
	    <div class="field-inline-block">
	      <label>MM</label>
	      <input type="text" pattern="[0-9]*" maxlength="2" size="2" class="date-field" />
	    </div>
	    /
	    <div class="field-inline-block">
	      <label>YYYY</label>
	      <input type="text" pattern="[0-9]*" maxlength="4" size="4" class="date-field date-field--year" />
	</div><br><br>
        <input type='radio' id='male' checked='checked' name='radio'>
        <label for='male'>Male</label>
        <input type='radio' id='female' checked="checked" name='radio'>
        <label for='female'>Female</label><br><br>
        <button class="bt"><b>Sign Up</b></button><br><br>   
        <a href="login.php" style="font-family: 'San Francisco';"><b>Already have an account ?</b></a><br><br>
	</form>
	</div>
</body>
</html>