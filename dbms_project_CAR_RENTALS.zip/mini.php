<?php
$conn=mysqli_connect("localhost","root","","user");
if(!$conn){
	die("connection Failed".mysqli_connect_error());
}
if(isset($_POST["Convert"])){
$query="SELECT * FROM booknow WHERE carname='MINI Cooper Convertible'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
      
      echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["Country"])){
$query="SELECT * FROM booknow WHERE carname='MINI Cooper Countryman'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
         echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>

                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["Door"])){
$query="SELECT * FROM booknow WHERE carname='MINI Cooper 3 Door'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
        echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
           }
         }
       }

if(isset($_POST["Works"])){
$query="SELECT * FROM booknow WHERE carname='MINI John Cooper Works'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
   echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["Se"])){
$query="SELECT * FROM booknow WHERE carname='MINI Cooper SE'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
          echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
        
}
}
}

if(isset($_POST["Clubman"])){
$query="SELECT * FROM booknow WHERE carname='MINI Clubman'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
          echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";



                      
}
}
}


if(isset($_POST["hondacity"])){
$query="SELECT * FROM booknow WHERE carname='HONDA CITY'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
         echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
              </span>
              </span>
              </div>";
        
}
}
}

if(isset($_POST["dzire"])){
$query="SELECT * FROM booknow WHERE carname='SWIFT DEZIRE'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
         echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
              </span>
              </span>
              </div>";
        
}
}
}

if(isset($_POST["ciaz"])){
$query="SELECT * FROM booknow WHERE carname='MARUTI SUZUKI-CIAZ'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
         echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
           }
         }
       }

if(isset($_POST["jaguar"])){
$query="SELECT * FROM booknow WHERE carname='JAGUAR XF'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
        echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
        
}
}
}

if(isset($_POST["virtus"])){
$query="SELECT * FROM booknow WHERE carname='VOLKSWAGEN-VIRTUS'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
     echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["R"])){
$query="SELECT * FROM booknow WHERE carname='Maruti-Suzuki-Wagon-R'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
      echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
              </span>
              </span>
              </div>";
        
}
}
}

if(isset($_POST["creta"])){
$query="SELECT * FROM booknow WHERE carname='HYUNDAI-CRETA'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
      echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["xuv700"])){
$query="SELECT * FROM booknow WHERE carname='MAHINDRA XUV 700'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
     echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["toyota"])){
$query="SELECT * FROM booknow WHERE carname='TOYOTA FORTUNER'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
     echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
           }
         }
       }

if(isset($_POST["scorpio"])){
$query="SELECT * FROM booknow WHERE carname='MAHINDRA SCORPIO'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
   echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              
        
}
}
}

if(isset($_POST["hyryder"])){
$query="SELECT * FROM booknow WHERE carname='TOYOTA HYRDER'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
     echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";


}
}
}

if(isset($_POST["tata"])){
$query="SELECT * FROM booknow WHERE carname='TATA HARRIER'";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
          
     echo "<span class=' row container-fluid  ' style='width:90%; margin:50px 0px 0px 80px;  '>
               <div class='container col-sm-1 p-3 ' ><center><img src='data:image;base64,".base64_encode($row['pic'])."' alt='Image' style='width:400px ; height:300px; border-radius:30px; color:rgb(156,0,52)'></center></div>
              <span class='container col-sm-4 mt-5 pt-5 ps-5 ms-5 me-5 p-0 ' style='width:500px; height:500px; margin-left:200px '><p class='text-center h2'><i><h2><strong><center>$row[carname]</center></strong></i></h2></p>

              <span class='card shadow p-5 m-5' style='width:10%; ' >
                        
                        
                        <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Cost:</strong></i> $row[cost] </p>
                         <p class='h4' style='margin-left:550px;'><i><strong><span
                        >&#10003;</span> &nbsp;&nbsp;Model/Brand:</strong></i> $row[model] </p>
                        <p class='h4' style='margin-left:150px; margin-right:50px'><i><strong><span>&#10003;</span> &nbsp;&nbsp;About car :</strong></i> $row[about] </p>
                       
              </span>
              </span>
              </div>";
              $url = 'nm.jpg';

        
}
}
}

?>
<style>
  .final{
    color: whitesmoke;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    padding-bottom: 5px;
    font-weight: bolder;
    background-color: rgb(228, 32, 14);
    margin: 0px 100px 0px 100px;
    border: solid black;
  
  }
  
    body
{
background-image:url('<?php echo $url ?>');
}



  
</style>

<html>
<head>
  <body >
      
     <a href="front.html"><center><button class="final" name="submit">Proceed</p></button></center></a>

  </body>
</head>
</html>