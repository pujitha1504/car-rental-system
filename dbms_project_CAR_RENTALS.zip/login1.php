<?php
$server_name="localhost";
$user_name="root";
$password="";
$database_name="user";
$conn = mysqli_connect($server_name,$user_name,$password,$database_name);
if(!$conn){
    die("Connection Failed" . mysqli_connect_error());
}
if(isset($_POST['login_user'])){
    $email=$_POST["email"];
    $pass=$_POST['pass'];
}
$flag=true;
$query ="SELECT email,password FROM reg_det";
$result = $conn->query($query);
if($result->num_rows >0){
    while($row = $result->fetch_assoc()){
        echo $row['email']. "." .$row['email'];
        if($row['email'] == $email){
            if($row['pass'] == $password){
                $flag=false;
                header('Location:http://localhost/Apps/minihtml.html');
                
            }
            else{
                $flag=false;
                header('Location:http://localhost/Apps/login.php');
            }
        }
    }
    if($flag){
        header("Location:http://localhost/Apps/register.php");
    }
}
?>