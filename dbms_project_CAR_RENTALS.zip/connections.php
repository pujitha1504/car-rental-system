<?php
	$f_name= $_POST['f_name'];
	$l_name= $_POST['l_name'];
	$email= $_POST['email'];
	$password= $_POST['password'];
	$date= $_POST['date'];
	$month= $_POST['month'];
	$year= $_POST['year'];
	$gender= $_POST['gender'];

	//Database connection
	$conn=new mysqli('localhost','root','','test');
	if($conn->connect_error){
		die('Connection Failed : '.$conn->connect_error);
	}
	else{
		$stmt= $conn->prepare("insert into reg_det(f_name,l_name,email,password,date,month,year,gender) values(?,?,?,?,?,?,?,?)");
		$stmt->bind_param("ssssiiis",$f_name,$l_name,$email,$password,$date,$month,$year,$gender);
		$stmt->execute();
		echo "registration Successfull...";
		$stmt->close();
		$conn->close();

	}
	
?>
