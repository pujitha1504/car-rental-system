<?php
$con=mysqli_connect("localhost","root","","user") ;
if(!$con)
{
    die("Connection Failed:" .mysqli_connect_error());
}
else
{
if(isset($_POST['submit']))
{
    
  //if(isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['password']))
  //{
    $ploc= $_POST['pick'];
	$dloc= $_POST['drop'];
	$ptime= $_POST['ptime'];
	$dtime= $_POST['dtime'];
	
      $in="insert into pick_data(ploc,dloc,ptime,dtime) values('$ploc','$dloc','$ptime','$dtime')";
      $query=mysqli_query($con,$in);
       if($query)
      {
          header('Location:http://localhost/Apps/last.html');
      }
      else
      {
        echo "unsuccessful";
      } 
      
}
}
?>