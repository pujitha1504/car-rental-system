<?php
$con=mysqli_connect("localhost","root","","user") ;
if(!$con)
{
    die("Connection Failed:" .mysqli_connect_error());
}
else
{
if(isset($_POST['bbt']))
{
    
  //if(isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['password']))
  //{
  $f_name= $_POST['f_name'];
	$l_name= $_POST['l_name'];
	$email= $_POST['email'];
	$password= $_POST['password'];
	$date= $_POST['date'];
	$month=$_POST['month'];
	$year= $_POST['year'];
	$gender= $_POST['gender'];
      $in="insert into reg_det(f_name,l_name,email,password,date,month,year,gender) values('$f_name','$l_name','$email','$password','$date','$month','$year','$gender')";
      $query=mysqli_query($con,$in);
      if($query)
      {
        //echo "success";
         header('Location:http://localhost/Apps/main.html');
      }
      else
      {
        echo "unsuccessful";
      } 
}
}
?>
<style>
.card{
	box-shadow: 0 4px 8px 0 rgba(0, 0, 0,0.2); 
	transition: 0.3s; 
	border-radius: 15px; 
	width: 30%;
	margin-left:0px;   
	margin-right: 10px; 
	margin-top: 10PX;  
	background-color: #008000;

} 
.bt{
  background-color: #008000;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 50%; 
  height: 50px;
  opacity: 0.9; 
  border-radius: 6px; 
  font-size: 20px; 
}

#hp
{
  float: left; 
  margin: 0 15px 0 0 ;
}

h5 
{
  margin: 10px 350px 10px 5px; 
  color: #868882;
}

.in
{
	background-color: whitesmoke; 
	color: black; 
	padding: 16px 20px; 
	border: none; 
	cursor: pointer; 
	width: 10px; 
	opacity: 0.9; 
	border-radius: 5px; 

}

img
{
  border-radius: 10px; 
  margin-left: 20px;
}


.imgbt
{
  background-image: url("car18.jpg");

min-height: 350px;

background-position: center;
background-repeat: no-repeat;
background-size: cover;
position: relative; 
background-attachment: fixed;
} 


label{
  user-select: none;
}
input[type="radio"] {
  display: none;
}

input[type="radio"] + label {
  z-index: 10;
  margin: 0 10px 10px 0;
  position: relative;
  color: #ced4da;
  text-shadow: 0 1px 0 rgba(255, 255, 255, 0.1);
  font-weight: bold;
  background-color: #ffffff;
  border: 2px solid #ced4da;
  cursor: pointer;
  transition: all 200ms ease;
}

input[type="radio"]:checked + label {
  color: #495057;
  background-color: #ced4da;
}

input[type="radio"] + label {
  padding: 5px 20px;
  border-radius: 10px;
} 


section {
  margin: 0 auto 1rem auto;
}

fieldset {
  border: none;
  background: #efefef;
  margin-bottom: 0.5rem;
}

input{
  font-family: 'Roboto', sans-serif;
  border: solid 1px #89a6bb;
  padding: 0.5rem;
  border-radius: 3px;
  -webkit-appearance: none;
}



.date-field {
  width: 30px;
  text-align: center;
}

.field-inline-block {
  display: inline-block;
  margin-right: 5px;
  margin-left: 5px;   
}

.kp{
	text-align: center; 
	font-size: 15px; 
	margin: 5px 0 5px 0px;
}
</style>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registration Process</title> 
	<link rel="stylesheet" href="style.css"> 
	<script type="text/javascript" src="data.js"></script>
	<link rel="shortcut icon" type="image/png" href="logo.jpg">
</head>
<body class="imgbt" style="background-image: url(tesla.jpg); background-repeat: repeat-x"><br>
	<img src="logo.jpg" width="50" height="50" id="hp">
	<div class="card" style="width:300px; margin-right:150px; "><br>
		<legend><h2><b><center>Create a new account</center></b></h2></legend> 

		<form style="text-align: center;" method="POST"> 
			
		<input class="in" type="text" name="f_name" placeholder="Enter the first name " required><br><br>
		<input class="in" type="text" name="l_name" placeholder="Enter the last name " required><br><br> 
		<input class="in" type="email" name="email" placeholder="Enter the email " required><br><br>  
		<input class="in" type="password" name="password" placeholder="Enter the password " required>
	      <br>
		
		<label class="l"><h5> DOB: </h5></label>
	    <div class="field-inline-block">
	    	<label>DD</label>
	      <input type="text" pattern="[0-9]*" maxlength="2" size="2" class="date-field" name="date" />
	    </div>
	    
	    <div class="field-inline-block">
	      <label>MM</label>
	      <input type="text" name="month" pattern="[0-9]*" maxlength="2" size="2" class="date-field" />
	    </div>
	    
	    <div class="field-inline-block">
	      <label>YYYY</label>
	      <input type="text" pattern="[0-9]*" name="year" maxlength="4" size="4" class="date-field date-field--year" />
	</div><br><br>
        <input type='radio' id='male' checked='checked' name='gender' value="m">
        <label for='male'>Male</label>
        <input type='radio' id='female' checked="checked" name='gender' value="f">
        <label for='female'>Female</label><br><br>
        <button class="bt" name="bbt"><b>Sign Up</b></button><br><br>   
        <a href="login.html" style="font-family: 'San Francisco';"><b>Already have an account ?</b></a><br><br>
	</form> 
</div>
	</div>
</body>
</html>