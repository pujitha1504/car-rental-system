<?php
$db_connect = mysqli_connect('localhost','root','','user') or die('connection failed');

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Product Information</title>
<style>
.box {
    margin:100px 0px 0px 50px;
    font-style:italic;
    font-size:10px;
    padding-left:20px;
    display: grid;
}
img{
  float: left;
  width: 300px;
  height:350px;
  
}
.box .aaa{
  margin-top:20px;

}
.box .names{
  margin:0px 0px 0px 10px;

}


</style>
</head>
<body>

  
<?php $all_orders = mysqli_query($db_connect, "SELECT * FROM `booknow` where carname='MINI Cooper Countryman'");

if (mysqli_num_rows($all_orders) > 0) {
  while ($row = mysqli_fetch_assoc($all_orders)) {?>
 
    <div class="box">
      
    <p> 
      
      <span class="aaa">
        <img src = <?php echo $row['pic']?>>
       </span> 
     
      <span class="names">
      <h1><?= $row['carname'] ?></h1>
      <h1> <?= $row['cost'] ?> </h1>
      <h1> <?= $row['det'] ?> </h1>
   
    </span>
  </p>
    </div>
<?php }} else {
        echo '<p class="empty">no feedbacks placed yet!</p>';
      }
      ?>
</body>
</html>